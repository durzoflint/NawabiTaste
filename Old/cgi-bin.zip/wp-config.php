<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'nawabita_wp530');

/** MySQL database username */
define('DB_USER', 'nawabita_wp530');

/** MySQL database password */
define('DB_PASSWORD', 'uAiS.8p!22');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '1ejfmzm5ebltn92lhhczgeof7wzq2slckfi83xbljioqq2nifqtyjzigdijx6pqw');
define('SECURE_AUTH_KEY',  'ctlhyafg8qppjdzoj1wdgquipxlgml9byvdva4qqxfs0sa9xgro0ksthdagvoirq');
define('LOGGED_IN_KEY',    '3bkhrgo0crzo9ajsxfdb8t1yrnkw2huroslvirsryzou4atnt9vxuoqtefxuzvt1');
define('NONCE_KEY',        'h3533v8iua9xko4csis3c36zagi6ov9ybujbqwws9ejnuyhypvwbmgsr3v0gvlfc');
define('AUTH_SALT',        'pjregflk5oof1xuyqxdmdmf3xdee8vpqnylbfipvivhtbhqkwkcexqvpd5l2bwqn');
define('SECURE_AUTH_SALT', 'io8qhczjnjx1t07ocdpml5s8re0oslqglaydsm4fcm04omsqfhxge8b5qc7ieph6');
define('LOGGED_IN_SALT',   'spwsfr5n9kts80bxjnocerqrdaqqxwef7l2yvgj86vrimsbct9qrfdsw1vjggco0');
define('NONCE_SALT',       'zqptkdrfeieopnvunz6vqd50wzexalp9j7yjrnhclea5vtyceqay0e1xb5xnaccj');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpxc_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
